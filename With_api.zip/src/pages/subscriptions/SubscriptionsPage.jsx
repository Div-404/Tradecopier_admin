import React, { useState } from 'react';
import { useSuperAdmin } from '../../context/SuperAdminContext';
import CreatePackageModal from '../../components/modals/CreatePackageModal';
import UserTypeUrlModal from '../../components/modals/UserTypeUrlModal';

export default function SubscriptionsPage() {
  const { packages, deletePackage } = useSuperAdmin();

  // Modal states
  const [isCreatePackageOpen, setIsCreatePackageOpen] = useState(false);
  const [isUrlModalOpen, setIsUrlModalOpen] = useState(false);

  return (
    <div>
      {/* Create Package Modal */}
      <CreatePackageModal 
        isOpen={isCreatePackageOpen} 
        onClose={() => setIsCreatePackageOpen(false)} 
      />

      {/* User Type URLs Modal */}
      <UserTypeUrlModal
        isOpen={isUrlModalOpen}
        onClose={() => setIsUrlModalOpen(false)}
        initialProfileId="10001"
      />

      {/* Page Header */}
      <div className="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-3">
        <div>
          <div className="d-flex align-items-center gap-2">
            <h4 className="fw-bolder text-dark m-0" style={{ letterSpacing: '-0.4px' }}>
              Subscription Packages for Brokers
            </h4>
            <span className="badge rounded-pill bg-success bg-opacity-10 text-success border border-success border-opacity-25 px-2.5 py-1" style={{ fontSize: '0.72rem', fontWeight: 600 }}>
              <i className="bi bi-box-seam me-1"></i> {packages.length} Packages
            </span>
          </div>
          <span className="text-secondary" style={{ fontSize: '0.85rem' }}>
            Official TradeCopier modules. Assign subscriptions to approved brokerages and manage copier URLs.
          </span>
        </div>

        <div className="d-flex align-items-center gap-2">
          <button 
            type="button" 
            className="btn btn-outline-primary fw-semibold d-flex align-items-center gap-1.5"
            onClick={() => setIsUrlModalOpen(true)}
          >
            <i className="bi bi-link-45deg fs-5"></i>
            <span>User Type URLs API</span>
          </button>

          <button 
            type="button" 
            className="btn btn-neon-primary shadow-sm d-flex align-items-center gap-1.5"
            onClick={() => setIsCreatePackageOpen(true)}
          >
            <i className="bi bi-plus-lg"></i>
            <span>Create Package</span>
          </button>
        </div>
      </div>

      {/* Subscription Module Cards Grid */}
      <div className="row g-3 row-cols-1 row-cols-sm-2 row-cols-lg-4 mb-4">
        {packages.map((pkg) => {
          return (
            <div className="col" key={pkg.id}>
              <div className="subscription-module-card">
                {/* Title and Subtitle */}
                <div>
                  {/* Title */}
                  <div className="subscription-module-title">
                    {pkg.name}
                  </div>

                  {/* Subtitle */}
                  <div className="subscription-module-subtitle">
                    {pkg.subtitle || "Broker Module"}
                  </div>
                </div>

                {/* Bottom Action Area: Edit & Delete Side-by-Side Buttons */}
                <div className="d-flex align-items-center gap-2 mt-auto pt-2 w-100">
                  <button 
                    type="button" 
                    className="btn btn-sm d-flex align-items-center justify-content-center gap-1 flex-fill"
                    onClick={() => setIsUrlModalOpen(true)}
                    style={{ 
                      height: '38px', 
                      borderRadius: '8px', 
                      backgroundColor: '#ffffff',
                      border: '1px solid #d1d5db',
                      fontWeight: 500,
                      fontSize: '0.85rem',
                      cursor: 'pointer',
                      transition: 'all 0.15s ease'
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.backgroundColor = '#f8fafc';
                      e.currentTarget.style.borderColor = '#94a3b8';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.backgroundColor = '#ffffff';
                      e.currentTarget.style.borderColor = '#d1d5db';
                    }}
                  >
                    <i className="bi bi-link-45deg" style={{ fontSize: '0.85rem', color: '#2563eb' }}></i>
                    <span style={{ color: '#1e40af' }}>URLs</span>
                  </button>

                  <button 
                    type="button" 
                    className="btn btn-sm d-flex align-items-center justify-content-center gap-1 flex-fill"
                    onClick={() => deletePackage(pkg.id)}
                    style={{ 
                      height: '38px', 
                      borderRadius: '8px', 
                      backgroundColor: '#ffffff',
                      border: '1px solid #d1d5db',
                      fontWeight: 500,
                      fontSize: '0.85rem',
                      cursor: 'pointer',
                      transition: 'all 0.15s ease'
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.backgroundColor = '#fef2f2';
                      e.currentTarget.style.borderColor = '#fca5a5';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.backgroundColor = '#ffffff';
                      e.currentTarget.style.borderColor = '#d1d5db';
                    }}
                  >
                    <i className="bi bi-trash3" style={{ fontSize: '0.85rem', color: '#dc2626' }}></i>
                    <span style={{ color: '#dc2626' }}>Delete</span>
                  </button>
                </div>

              </div>
            </div>
          );
        })}
      </div>

    </div>
  );
}
